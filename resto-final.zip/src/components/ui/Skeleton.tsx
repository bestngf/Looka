export default function Skeleton({ className = "" }: { className?: string }) {
  return <div aria-hidden="true" className={`animate-pulse rounded-xl bg-[var(--r-line)] motion-reduce:animate-none ${className}`} />;
}
